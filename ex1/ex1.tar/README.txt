323379768
206974586
*****
Comments:
In 6.2, since we had a lot of expiraments during the Targil, we descovered manhathan distance
is clearly suprior in efficiency. So, by splitting the problem into sub-problems like in 6.1 
it finds the solution super fast, checking that we are not blocking the real solution.
Was worth a shot, maybe we will win who knows.
